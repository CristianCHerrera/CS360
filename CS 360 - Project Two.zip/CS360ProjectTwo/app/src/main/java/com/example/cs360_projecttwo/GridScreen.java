package com.example.cs360_projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GridScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_screen);
    }
}