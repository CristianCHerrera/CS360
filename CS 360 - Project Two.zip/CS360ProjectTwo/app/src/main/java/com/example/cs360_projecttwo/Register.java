package com.example.cs360_projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {


    EditText enterUsername,enterPassword,reEnterPassword;
    Button registerButton;
    DBHelper myDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        enterUsername = (EditText) findViewById(R.id.enterUsername);
        enterPassword = (EditText) findViewById(R.id.enterPassword);
        reEnterPassword = (EditText) findViewById(R.id.reEnterPassword);
        registerButton = (Button) findViewById(R.id.registerButton);


        myDatabase = new DBHelper(this);

        registerButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String user = enterUsername.getText().toString();
                String pass = enterPassword.getText().toString();
                String repass = reEnterPassword.getText().toString();
                if (user.equals("") || pass.equals("") || repass.equals("")){
                    Toast.makeText(Register.this, "Fill all the fields.", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(pass.equals(repass)){
                        Boolean userResult = myDatabase.verifyUser(user);
                        if (userResult == false){
                            Toast.makeText(Register.this, "Password not matching.", Toast.LENGTH_SHORT).show();
                        }
                        else{

                        }
                    }
                    else{
                        Toast.makeText(Register.this, "Password not matching." ,Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}